import requests
import re
import os
user = input("Enter the image name you want: ")
user_agent = {
    "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36"
}



url = f"https://www.google.com/search?sca_esv=18a6e92da9c605eb&sxsrf=AE3TifN8FmWcxJlu7YPNwQ-Hs8Nbe4FlhA:1767004081878&udm=2&fbs=AIIjpHxU7SXXniUZfeShr2fp4giZ1Y6MJ25_tmWITc7uy4KIeuYzzFkfneXafNx6OMdA4MQRJc_t_TQjwHYrzlkIauOKj9nSuujpEIbB1x32lFLEvBmmX-p1UI3WlSFH86-EF1CpFR0tZjCgi5bM20K3xHOK3droXh0yMXraJ5han3x4rkl9Co5S6JKPNx1fHkXHoy-qehbRF1XGgIa6fKwyF5LNOJ-3xQ&q={user}&sa=X&ved=2ahUKEwjuwfeUy-KRAxXTSmwGHaDdHEcQtKgLegQIGhAB&biw=1745&bih=866&dpr=1.1"

response = requests.get(url=url, headers=user_agent).text

# Use a capturing group () to extract only the URL and handle more image types.
pattern = r"\[\"(https://[^\"]*?\.(?:jpg|jpeg|png))\",\s*[0-9]+,\s*[0-9]+\]"

images = re.findall(pattern,response)
images = list(dict.fromkeys(images))
print(f"Total Images: {len(images)}")
no_of_images = int(input("Number of images to be downloaded: "))

if images:
    print("\n--- Starting Download ---")
    for i, image_url in enumerate(images[:no_of_images]):
        print(f"Downloading image {i+1} from {image_url}")
        try:
            image_response = requests.get(image_url, headers=user_agent, timeout=10)
            image_response.raise_for_status() # Raise an exception for bad status codes (like 404)

            filename = f"{user.replace(' ', '_')}_{i+1}.jpg" # Create a simple, safe filename
            with open(filename, "wb") as f:
                f.write(image_response.content)
            print(f"Successfully saved as {filename}")
        except requests.exceptions.RequestException as e:
            print(f"Could not download image. Error: {e}")