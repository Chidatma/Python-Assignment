import requests
from bs4 import BeautifulSoup

class PriceTracer:
    def __init__(self,url):
        self.url = url
        self.user_agent = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36"}
        self.response = requests.get(url = self.url,headers= self.user_agent).text
        self.soup = BeautifulSoup(self.response,"lxml")
    
    def product_title(self) :
        title = self.soup.find("span", {"id":"productTitle"})
        if title is not None:
            return title.text.strip()
        else:
            return "Tag Not Found"


    def product_price(self):
        price = self.soup.find("span",{"class":"a-price-whole"})
        if price is not None:
            return price.text
        else:
            return "Tag Not Found"


device = PriceTracer(url = "https://www.amazon.in/iPhone-17-Pro-Max-Promotion/dp/B0FQFVX9ZZ/ref=sr_1_4?crid=G5YZTKSQ2WW5&dib=eyJ2IjoiMSJ9.GcmVHpiRV9y7__apxOj82XvH-Na8tqvYirdAbkllilw4MyW6pasMk6rdF-lD_6uAHJN6Vnko7HoJKINWS8prV73cLiLX3mM2NP2tnt9FlobFU7UmmD_ydbfCvFsq64AatedZfApFNFEDlwWRx0D2lpW9uxd3YIOwDssloS5j6bS5EQOVRfMxI3LimUd294U9hKKk3AXAsu8sovL_twBzfutHdr10_viTU2yLu5cenko.VLCNlkZiu4XWWZUxtVkNshFSoIfYHDR7LRx9izi1mXY&dib_tag=se&keywords=mobile+iphone+17+pro+max&qid=1767007719&sprefix=mobile+iphone+17%2Caps%2C387&sr=8-4")
print(device.product_title())
print(device.product_price())