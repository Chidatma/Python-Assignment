import urllib.request,urllib.parse, urllib.error

try:
    url = urllib.request.urlopen("http://127.0.0.1:8000/helloworld/")
    for line in url:
        print(line.decode().strip())
except urllib.error.URLError:
    print("Connection refused. Make sure the local web server is running on port 8000.")