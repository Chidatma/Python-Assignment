import requests
from bs4 import BeautifulSoup
import csv

def Extract(url):
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'}
    response = requests.get(url=url, headers=headers).content
    soup = BeautifulSoup(response,'lxml')
    tag = soup.find(id="mp-right")
    if tag:
        h = tag.find_all("h2")
        content = [span.text for span in h]
        print(content)
    else:
        print("Tag 'mp-right' not found. The request might be blocked or the page structure changed.")

    with open("wiki.csv","w") as csv_file:
        csv_write = csv.writer(csv_file)
        csv_write.writerow(content)


Extract(url="https://en.wikipedia.org/wiki/Main_Page")