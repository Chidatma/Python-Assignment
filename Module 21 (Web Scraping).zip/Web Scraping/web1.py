import requests

url = "https://img.freepik.com/free-photo/beautiful-lake-mountains_395237-44.jpg?semt=ais_hybrid&w=740&q=80"
user = {
    "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36"
}
response = requests.get(url = url,headers=user)
# print(response.request.headers)
pic = response.content

f = open("beautiful-lake-mountains_395237-44.jpg","wb")

f.write(pic)