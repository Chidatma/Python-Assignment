from http.server import HTTPServer, BaseHTTPRequestHandler

class SimpleHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        print(f"DEBUG: Received request for path: {self.path}")
        if self.path == '/':
            self.send_response(200)
            self.send_header('Content-type', 'text/plain')
            self.end_headers()
            self.wfile.write(b"Welcome to the Home Page!")
        elif self.path == '/helloworld/' or self.path == '/helloworld':
            self.send_response(200)
            self.send_header('Content-type', 'text/plain')
            self.end_headers()
            self.wfile.write(b"Hello World from the server!")
        else:
            self.send_error(404, "Page Not Found")

if __name__ == '__main__':
    server_address = ('127.0.0.1', 8000)
    httpd = HTTPServer(server_address, SimpleHandler)
    print("Server running on http://127.0.0.1:8000/ ... (Press Ctrl+C to stop)")
    httpd.serve_forever()
