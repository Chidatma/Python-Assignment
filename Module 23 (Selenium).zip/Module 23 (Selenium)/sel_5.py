from selenium import webdriver
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options

options = Options()
options.add_experimental_option("detach", True)

driver = webdriver.Chrome(options=options)
driver.get('http://www.amazon.in')

select = driver.find_elements(By.LINK_TEXT, 'Continue shopping')
if len(select) > 0:
    select[0].click()

driver.maximize_window()

driver.find_element(By.XPATH, "//input[@id='twotabsearchtextbox']").send_keys('iphones')

driver.find_element(By.XPATH, "//input[@id='nav-search-submit-button']").click()

time.sleep(5)
list = driver.find_elements(By.XPATH, "//div[@data-component-type='s-search-result']//h2//span")

print(f"Total products found: {len(list)}")
print("-" * 100)
print(f"{'Index':<10} | {'Product Name'}")
print("-" * 100)

for index, item in enumerate(list, start=1):
    print(f"{index:<10} | {item.text}")
