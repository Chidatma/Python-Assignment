from selenium import webdriver
import time
from selenium.webdriver.chrome.options import Options
options = Options()
options.add_experimental_option("detach", True)
driver = webdriver.Chrome(options=options)
driver.get('http://www.google.com')

input = driver.find_element_by_name('q')
input.send_keys('selenium')
time.sleep(5)

button = driver.find_element_by_name('btnK')
button.click()

time.sleep(5)
driver.back()
time.sleep(5)
driver.forward()
time.sleep(5)

driver.quit()