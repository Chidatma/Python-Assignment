import subprocess
import sys
import time

# Launch Server
subprocess.Popen([sys.executable, "server.py"])

# Give server a moment to bind
time.sleep(1)

# Launch Client
subprocess.Popen([sys.executable, "client_gui.py"])