# Hello Sir, Because of the IP address show in my terminal when i run it, therefore i don't record the video. But i 100% sure that this code perfectly run on my local machine.
# Thanks Sir!

import socket
from tkinter import *
import threading

def send(listbox,entry):
    message = entry.get()
    listbox.insert('end', "You: " + message)
    entry.delete(0,END)
    try:
        client.send(bytes(message,"utf-8"))
    except:
        listbox.insert('end', "Error: Client not connected")

def recieve():
    while True:
        try:
            message_from_client = client.recv(50)
            if not message_from_client: break
            listbox.insert('end', "Client: " + message_from_client.decode('utf-8'))
        except:
            break

def start_server():
    global client
    global s
    try:
        s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        HOST_NAME = socket.gethostname()
        PORT = 12345
        s.bind((HOST_NAME,PORT))
        s.listen(4)
        listbox.insert('end', f"Server listening on {HOST_NAME}:{PORT}")
        
        client, address = s.accept()
        listbox.insert('end', f"Connection from {address}")
        
        t = threading.Thread(target=recieve)
        t.daemon = True
        t.start()
    except Exception as e:
        print(f"Server Error: {e}")

root = Tk()
root.title("Server Chat")
root.geometry("600x500")

scrollbar = Scrollbar(root)
scrollbar.pack(side=RIGHT, fill=Y)

entry = Entry()
entry.pack(side=BOTTOM, fill=X)

listbox = Listbox(root, yscrollcommand=scrollbar.set)
listbox.pack(fill=BOTH, expand=True)
scrollbar.config(command=listbox.yview)

button = Button(root,text="Send",command=lambda:send(listbox,entry))
button.pack(side=BOTTOM)

t_server = threading.Thread(target=start_server)
t_server.daemon = True
t_server.start()

root.mainloop()
