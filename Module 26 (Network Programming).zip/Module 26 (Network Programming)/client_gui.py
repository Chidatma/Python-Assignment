import socket
from tkinter import *
import threading

def send(listbox,entry):
    message = entry.get()
    listbox.insert('end', "You: " + message)
    entry.delete(0,END)
    try:
        s.send(bytes(message,"utf-8"))
    except:
        listbox.insert('end', "Error sending message")

def recieve():
    while True:
        try:
            message_from_server = s.recv(50)
            if not message_from_server: break
            listbox.insert('end', "Server: " + message_from_server.decode('utf-8'))
        except:
            break

def connect_to_server():
    global s
    try:
        s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        HOST_NAME = socket.gethostname()
        PORT = 12345
        s.connect((HOST_NAME,PORT))
        listbox.insert('end', "Connected to server")
        
        t = threading.Thread(target=recieve)
        t.daemon = True
        t.start()
    except Exception as e:
        listbox.insert('end', f"Connection Error: {e}")

root = Tk()
root.title("Client Chat")
root.geometry("600x500")

scrollbar = Scrollbar(root)
scrollbar.pack(side=RIGHT, fill=Y)

entry = Entry(root)
entry.pack(side=BOTTOM, fill=X)

listbox = Listbox(root, yscrollcommand=scrollbar.set)
listbox.pack(fill=BOTH, expand=True)
scrollbar.config(command=listbox.yview)

button = Button(root,text="Send",command=lambda:send(listbox,entry))
button.pack(side=BOTTOM)

t_connect = threading.Thread(target=connect_to_server)
t_connect.daemon = True
t_connect.start()

root.mainloop()