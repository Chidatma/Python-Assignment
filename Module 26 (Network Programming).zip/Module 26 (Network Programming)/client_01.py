import socket

try:
    s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)

    HOST_NAME = socket.gethostname()
    PORT = 12345
    s.connect((HOST_NAME,PORT))

    while True:
        message = s.recv(50)
        if not message:
            break
        print("Server: "+message.decode('utf-8'))

        msg = input("Client: ")
        s.send(bytes(msg, "utf-8"))
except Exception as e:
    print(f"Client Error: {e}")