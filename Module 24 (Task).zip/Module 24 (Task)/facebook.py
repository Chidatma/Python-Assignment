from selenium import webdriver
from selenium.webdriver.common.by import By
from time import sleep
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

options = webdriver.ChromeOptions()
options.add_experimental_option("detach", True)
options.add_argument("--disable-notifications")
driver = webdriver.Chrome(options=options)
driver.get('http://facebook.com')
emailelement = driver.find_element(By.XPATH,'.//*[@id="email"]')
emailelement.send_keys('u42258850@gmail.com')
passelement = driver.find_element(By.XPATH,'.//*[@id="pass"]')
passelement.send_keys('5H?2C=bSmpN&tnV')

elem = driver.find_element(By.NAME, 'login')
elem.click()

# Wait for login to complete and the 'Create Post' area to appear
wait = WebDriverWait(driver, 20)
post_trigger = wait.until(EC.element_to_be_clickable((By.XPATH, "//span[contains(text(), \"What's on your mind\")]")))
post_trigger.click()

# Wait for the post modal to open and type the message
post_input = wait.until(EC.element_to_be_clickable((By.XPATH, "//div[@role='dialog']//div[@role='textbox']")))
post_input.send_keys('Hi there')

# Click the 'Post' button
post_btn = wait.until(EC.element_to_be_clickable((By.XPATH, "//div[@role='dialog']//div[@aria-label='Post']")))
post_btn.click()
